export default function Home() {
  return (
    <div>
      <h1>Refund Guardian</h1>
      <p>Welcome to the Refund Guardian App</p>
    </div>
  );
}
