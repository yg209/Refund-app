const express = require('express');
const router = express.Router();

router.post('/create', async (req, res) => {
  const { user, refundAmount } = req.body;
  // TODO: Call RefundEscrow smart contract here via ethers.js
  res.json({ status: 'ok', user, refundAmount });
});

module.exports = router;
