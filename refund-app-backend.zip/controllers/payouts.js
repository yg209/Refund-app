const { Payout } = require('../models');
exports.requestPayout = async (req, res) => {
  try {
    const { amount, method } = req.body;
    const payout = await Payout.create({ user_id: req.user.id, amount, method, status: 'pending' });
    res.json(payout);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
exports.listPayouts = async (req, res) => {
  const payouts = await Payout.findAll({ where: { user_id: req.user.id } });
  res.json(payouts);
};
