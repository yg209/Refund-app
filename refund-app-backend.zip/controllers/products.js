const { Watch, Product } = require('../models');
exports.watchProduct = async (req, res) => {
  try {
    const { receiptId, title, minPrice } = req.body;
    const product = await Product.create({ title });
    const watch = await Watch.create({
      receipt_id: receiptId,
      product_id: product.id,
      min_price: minPrice || null
    });
    res.json({ product, watch });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
exports.listWatches = async (req, res) => {
  const watches = await Watch.findAll({ include: [{ model: Product }], where: {} });
  res.json(watches);
};
