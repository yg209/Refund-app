const { Claim, Receipt } = require('../models');
const { getPolicy } = require('../utils/policyDB');
const { buildClaimEmail } = require('../utils/claimTemplates');
exports.submitClaim = async (req, res) => {
  try {
    const { receiptId, retailer } = req.body;
    const receipt = await Receipt.findByPk(receiptId);
    if (!receipt) return res.status(404).json({ error: 'Receipt not found' });
    const policy = getPolicy(retailer);
    const emailBody = buildClaimEmail(receipt, policy);
    const claim = await Claim.create({ receipt_id: receipt.id, retailer, status: 'submitted', submitted_at: new Date() });
    res.json({ claim, emailBody });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
exports.getClaim = async (req, res) => {
  const claim = await Claim.findByPk(req.params.id);
  if (!claim) return res.status(404).json({ error: 'Not found' });
  res.json(claim);
};
