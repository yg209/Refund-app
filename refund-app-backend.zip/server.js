const app = require('./app');
const { sequelize } = require('./models');
const PORT = process.env.PORT || 3000;
sequelize.sync().then(() => {
  app.listen(PORT, () => {
    console.log(`Refund app backend running on port ${PORT}`);
  });
}).catch(err=>{
  console.error('Unable to start app', err);
});
