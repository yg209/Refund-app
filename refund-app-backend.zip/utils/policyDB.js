const policies = {
  bestbuy: { window_days: 15, proof_required: ['receipt','screenshot'], method: 'chat' },
  target: { window_days: 14, proof_required: ['receipt'], method: 'in_store' },
  amazon: { window_days: 30, proof_required: ['receipt'], method: 'contact_support' }
};
function getPolicy(retailer) { return policies[retailer.toLowerCase()] || null; }
module.exports = { getPolicy, policies };
