const jwt = require('jsonwebtoken');
module.exports = (req, res, next) => {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: 'Missing auth' });
  const token = header.replace('Bearer ', '');
  try {
    const data = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    req.user = { id: data.id };
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};
