function buildClaimEmail(receipt, policy) {
  const order = receipt.order_id || '(no order id)';
  const body = `Hi,\n\nI purchased an item (order ${order}) and found it for a lower price. Please refund the difference per your policy.\n\nThanks.`;
  return body;
}
module.exports = { buildClaimEmail };
