const Tesseract = require('tesseract.js');
async function parseReceipt(buffer) {
  try {
    const { data: { text } } = await Tesseract.recognize(buffer, 'eng', { logger: m => {} });
    return { text, confidence: 0.85 };
  } catch (err) {
    console.error('OCR error', err);
    return { text: '', confidence: 0 };
  }
}
module.exports = { parseReceipt };
