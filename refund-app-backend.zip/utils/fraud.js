const crypto = require('crypto');
const { Receipt } = require('../models');
async function hashBuffer(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}
async function checkDuplicate(buffer) {
  // simplistic duplicate check placeholder
  return false;
}
module.exports = { hashBuffer, checkDuplicate };
